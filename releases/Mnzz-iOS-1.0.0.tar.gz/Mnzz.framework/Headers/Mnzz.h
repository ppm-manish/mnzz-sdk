//
//  Mnzz.h
//  Mnzz
//
//  Created by Manish Kumar on 05/03/20.
//  Copyright © 2020 Manish Kumar. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for Mnzz.
FOUNDATION_EXPORT double MnzzVersionNumber;

//! Project version string for Mnzz.
FOUNDATION_EXPORT const unsigned char MnzzVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Mnzz/PublicHeader.h>


